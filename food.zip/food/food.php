<?php

$con = mysqli_connect('localhost', 'root', '','practise');

$txtName = $_POST['name'];
$txtEmail = $_POST['email'];
$txtPhnnum = $_POST['number'];
$txtFoodname = $_POST['foodname'];
$txtAddress = $_POST['address'];


	$sql = "INSERT INTO `orderfood` (`id`, `name`, `email` , `number` , `foodname`, `address`) VALUES ('0', '$txtName', '$txtEmail', '$txtPhnnum', '$txtFoodname', '$txtAddress')";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("order placed")';  
	echo '</script>';  

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("order donot received")';  
	echo '</script>';  
  
 }
