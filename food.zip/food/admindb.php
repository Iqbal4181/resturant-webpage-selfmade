<?php

$con = mysqli_connect('localhost', 'root', '','practise');

$txtName = $_POST['fname'];
$txtname = $_POST['lname'];
$txtPhnnum = $_POST['phnnum'];
$txtPassword = $_POST['pass'];
$txtConfirmPassword = $_POST['cpass'];


if($txtPassword == $txtConfirmPassword)
{
	$sql = "INSERT INTO `adregform` (`id`, `fname`, `lname` , `phnnum` , `pass`, `cpass`) VALUES ('0', '$txtName', '$txtname', '$txtPhnnum', '$txtPassword', '$txtConfirmPassword')";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Registration Successful")';  
	echo '</script>';  
	header("Location: login.html");

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Registration failed")';  
	echo '</script>';  
  
 }
}else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("incorrect password")';  
	echo '</script>';  
}

//$result = mysqli_query($con, $sql);



// if($result)
// {
// 	echo "Contact Records Inserted";
// }

?>