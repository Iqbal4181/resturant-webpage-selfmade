<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "practise";

// CREATE CONNECTION
$conn = mysqli_connect($servername,
	$username, $password, $databasename);

// GET CONNECTION ERRORS
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

// SQL QUERY
$query = "SELECT * FROM `orderfood`;";
// FETCHING DATA FROM DATABASE
$result = mysqli_query($conn, $query);



$conn->close();

?>





<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>List of ordered food </h2>

<table>
  <tr>
    <th>ID</th>
    <th>NAME</th>
    <th>EMAIL</th>
    <th>NUMBER</th>
    <th>FOODNAME</th>
    <th>ADDRESS</th>
    <th>ORDER TIME</th>
    <th colspan="2">update /delete</th>
  </tr>

  <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $rows['id'];?></td>
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['email'];?></td>
                <td><?php echo $rows['number'];?></td>
                <td><?php echo $rows['foodname'];?></td>
                <td><?php echo $rows['address'];?></td>
                <td><?php echo $rows['orderdateandtime'];?></td>
                <td><a href='updatefood.php?id=<?php echo $rows['id'];?>'>Edit/Update</a></td>
                <td><a href='deletefood.php?id=<?php echo $rows['id'];?>'>Delete</a></td>
            </tr>
            <?php
                }
            ?>
</table>

</body>
</html>


