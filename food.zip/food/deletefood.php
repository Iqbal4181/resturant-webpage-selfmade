
<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "practise";

// CREATE CONNECTION
$conn = mysqli_connect($servername,
	$username, $password, $databasename);

// GET CONNECTION ERRORS
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {  
    $id = $_GET['id'];  
    $query = "DELETE FROM `orderfood` WHERE id = '$id'";  
    $run = mysqli_query($conn,$query);  
    if ($run) {  
         header('location:admin order.php');  
    }else{  
         echo "Error: ".mysqli_error($conn);  
    }  
}  
?>