<?php



$servername = "localhost";
$username = "root";
$password = "";
$databasename = "practise";

// CREATE CONNECTION
$conn = mysqli_connect($servername,
	$username, $password, $databasename);

// GET CONNECTION ERRORS
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {  
    $id = $_GET['id']; 
    
    $query = "SELECT * FROM `orderfood` WHERE id = '$id'";  
    $run = mysqli_query($conn,$query); 
    $total = mysqli_num_rows($run);
    $result = mysqli_fetch_assoc($run);
    if ($run) {  
       echo $id;
    }else{  
         echo "Error: ".mysqli_error($conn);  
    }  
}  
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <link rel="stylesheet" href="styleform.css">
</head>
<body>
  <div class="form">
  <form action=""  method="POST">

    <div class="form_label">
    <label for="id">ID:  </label><input type="text" value="<?php echo $id;?>" name="id"> <br>
    <label for="name">Name: </label><input type="text" value="<?php echo $result['name']?>" name="name"> <br>
    <label for="Email">Email:  </label><input type="text" value="<?php echo $result['email']?>" name="email"> <br>
    <label for="phnnum">phone number:  </label><input type="text" value="<?php echo $result['number']?>" name="number"> <br>
    <label for="Address">Address:  </label><input type="text" value="<?php echo $result['address']?>" name="address"> <br>
    <label for="Food">Ordered Food:  </label><input type="text" value="<?php echo $result['foodname']?>" name="foodname"> <br>
    <input type="submit" value="Update" name="up"> <br>

</div>

  </form> 
</div> 
</body>
</html>

<?php

if(isset($_POST['up']))
{
    $txtName = $_POST['name'];
    $txtEmail = $_POST['email'];
    $txtPhnnum = $_POST['number'];
    $txtAddress = $_POST['address'];
    $txtFood = $_POST['foodname'];
    

        //$sql = "INSERT INTO `regform` (`id`, `fname`, `lname` , `phnnum` , `pass`, `cpass`) VALUES ('0', '$txtName', '$txtname', '$txtPhnnum', '$txtPassword', '$txtConfirmPassword')";
        $sql = "UPDATE `orderfood` SET name='$txtName',email='$txtEmail',number='$txtPhnnum',address='$txtAddress',foodname='$txtFood' WHERE id='$id'";
        $result = mysqli_query($conn, $sql);
        if($result)
    {
        echo '<script type ="text/JavaScript">';  
        echo 'record updated")';  
        echo '</script>';  
        header("Location: admin order.php");
    
     }
     else{
        echo '<script type ="text/JavaScript">';  
        echo 'alert("order update failed")';  
        echo '</script>';  
      
     }
     
}
?>