<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "practise";

// CREATE CONNECTION
$conn = mysqli_connect($servername,
	$username, $password, $databasename);

// GET CONNECTION ERRORS
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

// SQL QUERY
$query = "SELECT * FROM `regform`;";
// FETCHING DATA FROM DATABASE
$result = mysqli_query($conn, $query);



$conn->close();

?>





<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>user information </h2>

<table>
  <tr>
    <th>ID</th>
    <th>FIRST NAME</th>
    <th>LAST NAME</th>
    <th>PHONE NUMBER</th>
    <th>PASSWORD</th>
    <th>CONFIRM PASSWORD</th>
    <th colspan="2">update /delete</th>
    
  </tr>

  <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
                    //$id = $rows['id'];
                    
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                   
                <td><?php echo $rows['id'];?></td>
                <td><?php echo $rows['fname'];?></td>
                <td><?php echo $rows['lname'];?></td>
                <td><?php echo $rows['phnnum'];?></td>
                <td><?php echo $rows['pass'];?></td>
                <td><?php echo $rows['cpass'];?></td>
                <td><a href='update.php?id=<?php echo $rows['id'];?>'>Edit/Update</a></td>
                <td><a href='delete.php?id=<?php echo $rows['id'];?>'>Delete</a></td>
                </tr>
            <?php
                }
            ?>
</table>

</body>
</html>


