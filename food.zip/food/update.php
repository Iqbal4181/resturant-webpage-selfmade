<?php



$servername = "localhost";
$username = "root";
$password = "";
$databasename = "practise";

// CREATE CONNECTION
$conn = mysqli_connect($servername,
	$username, $password, $databasename);

// GET CONNECTION ERRORS
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {  
    $id = $_GET['id']; 
    
    $query = "SELECT * FROM `regform` WHERE id = '$id'";  
    $run = mysqli_query($conn,$query); 
    $total = mysqli_num_rows($run);
    $result = mysqli_fetch_assoc($run);
    if ($run) {  
       echo $id;
    }else{  
         echo "Error: ".mysqli_error($conn);  
    }  
}  
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <link rel="stylesheet" href="styleform.css">
</head>
<body>
  <div class="form">
  <form action=""  method="POST">

    <div class="form_label">
    <label for="id">ID:  </label><input type="text" value="<?php echo $id;?>" name="lname"> <br>
    <label for="fname">First name: </label><input type="text" value="<?php echo $result['fname']?>" name="fname"> <br>
    <label for="lname">Last name:  </label><input type="text" value="<?php echo $result['lname']?>" name="lname"> <br>
    <label for="phnnum">phone number:  </label><input type="text" value="<?php echo $result['phnnum']?>" name="phnnum"> <br>
    <label for="pass">password:  </label><input type="text" value="<?php echo $result['pass']?>" name="pass"> <br>
    <label for="cpass">Confirm password:  </label><input type="text" value="<?php echo $result['cpass']?>" name="cpass"> <br>
    <input type="submit" value="Update" name="up"> <br>

</div>

  </form> 
</div> 
</body>
</html>

<?php

if(isset($_POST['up']))
{
    $txtName = $_POST['fname'];
    $txtname = $_POST['lname'];
    $txtPhnnum = $_POST['phnnum'];
    $txtPassword = $_POST['pass'];
    $txtConfirmPassword = $_POST['cpass'];
    
    
    if($txtPassword == $txtConfirmPassword)
    {
        //$sql = "INSERT INTO `regform` (`id`, `fname`, `lname` , `phnnum` , `pass`, `cpass`) VALUES ('0', '$txtName', '$txtname', '$txtPhnnum', '$txtPassword', '$txtConfirmPassword')";
        $sql = "UPDATE `regform` SET fname='$txtName',lname='$txtname',phnnum='$txtPhnnum',pass='$txtPassword',cpass='$txtConfirmPassword' WHERE id='$id'";
        $result = mysqli_query($conn, $sql);
        if($result)
    {
        echo '<script type ="text/JavaScript">';  
        echo 'record updated")';  
        echo '</script>';  
        header("Location: home.html");
    
     }
     else{
        echo '<script type ="text/JavaScript">';  
        echo 'alert("record update failed")';  
        echo '</script>';  
      
     }
    }else{
        echo '<script type ="text/JavaScript">';  
        echo 'alert("password doesnot match")';  
        echo '</script>';  
    }
     
}
?>