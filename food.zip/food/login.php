<?php

$con = mysqli_connect('localhost', 'root', '','practise');
 session_start(); 




 $txtPhnnum = $_POST['phnnum'];
 $txtPassword = $_POST['pass'];



$sql = "select * from regform where phnnum = '$txtPhnnum' and pass = '$txtPassword'"; 




$result = mysqli_query($con, $sql);  
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
$count = mysqli_num_rows($result);

echo $count;


// $resultAll = mysqli_query($con, "select name,id,password from registration where email = '$txtEmail' and password = '$txtPassword'");
// if(!$resultAll){
// 	die(mysqli_error($con));
// }

// if (mysqli_num_rows($resultAll) > 0) {
// 	while($rowData = mysqli_fetch_array($resultAll)){
  		
//       $nam = $rowData["name"];
//       echo $nam;
//       $_SESSION['num']=$nam;
//       $id = $rowData['id'];
//       echo $id;
//       $_SESSION['id']=$id;
//       $password = $rowData['password'];
//       echo $password;
//       $_SESSION['password']=$password;

// 	}
// }


 if($count > 0){


 header("Location: ./home.html"); 
  }
 else{
  
  echo '<script type ="text/JavaScript">';  
 echo 'alert("Incorrect Email And Password")';  
 echo '</script>';   
  }
// }
?>